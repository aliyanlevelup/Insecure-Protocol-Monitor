#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════
#  Wall of Sheep — Install & Launch Script
#  Usage:  sudo ./run.sh              (live capture)
#          ./run.sh --demo            (demo mode, no root)
# ═══════════════════════════════════════════════════════════

set -euo pipefail

VENV_DIR=".venv"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo ""
echo "  🐑  Wall of Sheep — Internal Pentest Monitor"
echo "  ─────────────────────────────────────────────"
echo ""

# ── Python check ──────────────────────────────────────────
if ! command -v python3 &>/dev/null; then
    echo "  [✗] Python 3 not found. Install python3 first."
    exit 1
fi

PY_VER=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo "  [✓] Python $PY_VER"

# ── Virtual environment ───────────────────────────────────
if [ ! -d "$VENV_DIR" ]; then
    echo "  [→] Creating virtual environment…"
    python3 -m venv "$VENV_DIR"
fi

source "$VENV_DIR/bin/activate"
echo "  [✓] Virtualenv active"

# ── Install deps ──────────────────────────────────────────
echo "  [→] Installing dependencies…"
pip install -q --upgrade pip
pip install -q textual rich

# Try installing scapy (needs root for live capture anyway)
if pip install -q scapy 2>/dev/null; then
    echo "  [✓] Scapy installed — live capture available"
else
    echo "  [!] Scapy install failed — will run in demo mode"
fi

echo ""

# ── Root check ────────────────────────────────────────────
DEMO_FLAG=""
if [ "${1:-}" == "--demo" ]; then
    DEMO_FLAG="--demo"
    echo "  [→] Demo mode forced"
elif [ "$(id -u)" != "0" ]; then
    echo "  [!] Not running as root — raw packet capture unavailable"
    echo "  [!] Falling back to DEMO mode. Re-run with sudo for live capture."
    DEMO_FLAG="--demo"
fi

# ── Launch ────────────────────────────────────────────────
echo "  [→] Launching Wall of Sheep…"
echo ""
cd "$SCRIPT_DIR"
python3 main.py $DEMO_FLAG "$@"
