"""
Protocol parsers for credential extraction from raw packet payloads.
Supports: HTTP, FTP, Telnet, SMTP, POP3, IMAP, SNMP
"""

import re
import base64
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, List


INSECURE_PORTS = {
    21:  "FTP",
    23:  "Telnet",
    25:  "SMTP",
    80:  "HTTP",
    110: "POP3",
    143: "IMAP",
    161: "SNMP",
    389: "LDAP",
    8080:"HTTP",
    8888:"HTTP",
}

SEVERITY_MAP = {
    "HTTP":   "critical",
    "FTP":    "critical",
    "Telnet": "critical",
    "SMTP":   "high",
    "POP3":   "high",
    "IMAP":   "high",
    "SNMP":   "medium",
    "LDAP":   "high",
}

PROTOCOL_COLORS = {
    "HTTP":   "#ff4444",
    "FTP":    "#ff8800",
    "Telnet": "#ff0080",
    "SMTP":   "#ffff00",
    "POP3":   "#ff8800",
    "IMAP":   "#ff8800",
    "SNMP":   "#00aaff",
    "LDAP":   "#aa00ff",
    "DNS":    "#00ff88",
    "TCP":    "#444444",
    "UDP":    "#333333",
    "ARP":    "#005500",
}


@dataclass
class Credential:
    timestamp: str
    src_ip: str
    dst_ip: str
    src_port: int
    dst_port: int
    protocol: str
    username: str
    password: str
    method: str = ""
    hostname: str = ""

    @property
    def masked_password(self) -> str:
        p = self.password.strip()
        if not p:
            return "—"
        if len(p) <= 3:
            return "•" * len(p)
        return p[0] + "•" * (len(p) - 2) + p[-1]

    @property
    def display_host(self) -> str:
        return self.hostname if self.hostname else self.src_ip


@dataclass
class NetworkEvent:
    timestamp: str
    src_ip: str
    dst_ip: str
    src_port: int
    dst_port: int
    protocol: str
    info: str
    severity: str = "info"   # info | medium | high | critical
    size: int = 0


class ProtocolParser:
    """Stateless protocol parser. Returns lists of Credential / NetworkEvent."""

    # ── HTTP ──────────────────────────────────────────────────────────────
    _HTTP_BASIC   = re.compile(rb'Authorization:\s*Basic\s+([A-Za-z0-9+/=]+)', re.I)
    _HTTP_HOST    = re.compile(rb'Host:\s*([^\r\n]+)', re.I)
    _HTTP_METHOD  = re.compile(rb'^(GET|POST|PUT|DELETE|PATCH|HEAD)', re.I)
    _HTTP_USER    = re.compile(rb'(?:username|user|login|email|uname|usr)=([^&\s\r\n]{1,64})', re.I)
    _HTTP_PASS    = re.compile(rb'(?:password|passwd|pass|pwd|secret)=([^&\s\r\n]{1,64})', re.I)

    # ── FTP ───────────────────────────────────────────────────────────────
    _FTP_USER = re.compile(rb'^USER\s+(.+)', re.I | re.M)
    _FTP_PASS = re.compile(rb'^PASS\s+(.+)', re.I | re.M)

    # ── SMTP ──────────────────────────────────────────────────────────────
    _SMTP_PLAIN  = re.compile(rb'AUTH PLAIN\s+([A-Za-z0-9+/=]+)', re.I)
    _SMTP_LOGIN  = re.compile(rb'AUTH LOGIN', re.I)
    _SMTP_B64    = re.compile(rb'^([A-Za-z0-9+/=]{4,})\s*$', re.M)

    # ── POP3 ──────────────────────────────────────────────────────────────
    _POP3_USER = re.compile(rb'^USER\s+(.+)', re.I | re.M)
    _POP3_PASS = re.compile(rb'^PASS\s+(.+)', re.I | re.M)

    # ── IMAP ──────────────────────────────────────────────────────────────
    _IMAP_LOGIN = re.compile(
        rb'[A-Z0-9]+\s+LOGIN\s+"?([^"\s]{1,64})"?\s+"?([^"\s]{1,64})"?', re.I
    )

    # ── Telnet ────────────────────────────────────────────────────────────
    _TELNET_LOGIN = re.compile(rb'[Ll]ogin:\s*(\S+)')
    _TELNET_PASS  = re.compile(rb'[Pp]assword:\s*(\S+)')

    def parse(
        self,
        src_ip: str, dst_ip: str,
        src_port: int, dst_port: int,
        payload: bytes,
    ) -> tuple[List[Credential], List[NetworkEvent]]:
        creds: List[Credential] = []
        events: List[NetworkEvent] = []

        if not payload or len(payload) < 4:
            return creds, events

        ts = datetime.now().strftime("%H:%M:%S")
        low_dst, low_src = dst_port, src_port

        # HTTP / HTTPS cleartext
        if low_dst in (80, 8080, 8888) or low_src in (80, 8080, 8888):
            c, e = self._http(ts, src_ip, dst_ip, src_port, dst_port, payload)
            creds += c; events += e

        # FTP
        elif low_dst == 21 or low_src == 21:
            c, e = self._ftp(ts, src_ip, dst_ip, src_port, dst_port, payload)
            creds += c; events += e

        # Telnet
        elif low_dst == 23 or low_src == 23:
            c, e = self._telnet(ts, src_ip, dst_ip, src_port, dst_port, payload)
            creds += c; events += e

        # SMTP
        elif low_dst == 25 or low_src == 25:
            c, e = self._smtp(ts, src_ip, dst_ip, src_port, dst_port, payload)
            creds += c; events += e

        # POP3
        elif low_dst == 110 or low_src == 110:
            c, e = self._pop3(ts, src_ip, dst_ip, src_port, dst_port, payload)
            creds += c; events += e

        # IMAP
        elif low_dst == 143 or low_src == 143:
            c, e = self._imap(ts, src_ip, dst_ip, src_port, dst_port, payload)
            creds += c; events += e

        return creds, events

    # ── parsers ───────────────────────────────────────────────────────────

    def _http(self, ts, src, dst, sp, dp, data):
        creds, events = [], []
        host_m = self._HTTP_HOST.search(data)
        hostname = host_m.group(1).decode("utf-8", errors="replace").strip() if host_m else ""

        # Basic Auth
        m = self._HTTP_BASIC.search(data)
        if m:
            try:
                decoded = base64.b64decode(m.group(1)).decode("utf-8", errors="replace")
                if ":" in decoded:
                    user, pw = decoded.split(":", 1)
                    creds.append(Credential(ts, src, dst, sp, dp, "HTTP", user.strip(), pw.strip(), "Basic Auth", hostname))
            except Exception:
                pass

        # Form POST
        if b"POST" in data[:8]:
            users = self._HTTP_USER.findall(data)
            pwds  = self._HTTP_PASS.findall(data)
            if users and pwds:
                user = users[0].decode("utf-8", errors="replace")
                pw   = pwds[0].decode("utf-8", errors="replace")
                creds.append(Credential(ts, src, dst, sp, dp, "HTTP", user, pw, "Form POST", hostname))

        return creds, events

    def _ftp(self, ts, src, dst, sp, dp, data):
        creds, events = [], []
        pu = self._FTP_USER.search(data)
        pp = self._FTP_PASS.search(data)
        if pp:
            user = pu.group(1).decode("utf-8", errors="replace").strip() if pu else "?"
            pw   = pp.group(1).decode("utf-8", errors="replace").strip()
            creds.append(Credential(ts, src, dst, sp, dp, "FTP", user, pw, "FTP AUTH"))
        return creds, events

    def _telnet(self, ts, src, dst, sp, dp, data):
        creds, events = [], []
        ml = self._TELNET_LOGIN.search(data)
        mp = self._TELNET_PASS.search(data)
        if mp:
            user = ml.group(1).decode("utf-8", errors="replace").strip() if ml else "?"
            pw   = mp.group(1).decode("utf-8", errors="replace").strip()
            creds.append(Credential(ts, src, dst, sp, dp, "Telnet", user, pw, "Telnet Auth"))
        return creds, events

    def _smtp(self, ts, src, dst, sp, dp, data):
        creds, events = [], []
        m = self._SMTP_PLAIN.search(data)
        if m:
            try:
                decoded = base64.b64decode(m.group(1)).decode("utf-8", errors="replace")
                parts = decoded.split("\x00")
                if len(parts) >= 3:
                    creds.append(Credential(ts, src, dst, sp, dp, "SMTP", parts[1], parts[2], "AUTH PLAIN"))
            except Exception:
                pass
        return creds, events

    def _pop3(self, ts, src, dst, sp, dp, data):
        creds, events = [], []
        pu = self._POP3_USER.search(data)
        pp = self._POP3_PASS.search(data)
        if pp:
            user = pu.group(1).decode("utf-8", errors="replace").strip() if pu else "?"
            pw   = pp.group(1).decode("utf-8", errors="replace").strip()
            creds.append(Credential(ts, src, dst, sp, dp, "POP3", user, pw, "POP3 Auth"))
        return creds, events

    def _imap(self, ts, src, dst, sp, dp, data):
        creds, events = [], []
        m = self._IMAP_LOGIN.search(data)
        if m:
            user = m.group(1).decode("utf-8", errors="replace")
            pw   = m.group(2).decode("utf-8", errors="replace")
            creds.append(Credential(ts, src, dst, sp, dp, "IMAP", user, pw, "IMAP LOGIN"))
        return creds, events
