"""
SnifferEngine  —  captures packets on a given interface and emits
Credential / NetworkEvent objects via registered callbacks.
"""

import threading
import queue
from datetime import datetime
from typing import Callable, Optional

from core.protocols import (
    ProtocolParser, Credential, NetworkEvent,
    INSECURE_PORTS, PROTOCOL_COLORS,
)

try:
    from scapy.all import (
        sniff, IP, IPv6, TCP, UDP, DNS, DNSQR, ARP, Raw,
        get_if_list, conf,
    )
    SCAPY_OK = True
except ImportError:
    SCAPY_OK = False


class SnifferEngine:
    """Thread-safe packet sniffer. Calls on_credential / on_event callbacks."""

    def __init__(self):
        self.parser = ProtocolParser()
        self._stop_evt = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self.interface: str = "eth0"
        self.bpf_filter: str = ""        # e.g. "tcp port 80"
        self.promisc: bool = True

        # Callbacks — set by the UI layer
        self.on_credential: Optional[Callable[[Credential], None]] = None
        self.on_event: Optional[Callable[[NetworkEvent], None]] = None
        self.on_stat: Optional[Callable[[dict], None]] = None

        # Stats
        self.stats: dict = {
            "total": 0,
            "credentials": 0,
            "bytes": 0,
            **{p: 0 for p in INSECURE_PORTS.values()},
        }

        # Passive session tracker {(src,dst,sp,dp): list[bytes]}
        self._sessions: dict = {}

    # ── public API ─────────────────────────────────────────────────────────

    @staticmethod
    def list_interfaces() -> list[str]:
        if SCAPY_OK:
            return get_if_list()
        return ["eth0", "lo"]

    def start(self, iface: str = "eth0", bpf: str = ""):
        if self._thread and self._thread.is_alive():
            return
        self.interface = iface
        self.bpf_filter = bpf
        self._stop_evt.clear()
        self._thread = threading.Thread(target=self._run, daemon=True, name="sniffer")
        self._thread.start()

    def stop(self):
        self._stop_evt.set()

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    # ── internal ───────────────────────────────────────────────────────────

    def _run(self):
        if not SCAPY_OK:
            self._demo_mode()
            return
        try:
            conf.verb = 0
            sniff(
                iface=self.interface,
                filter=self.bpf_filter or None,
                prn=self._handle_pkt,
                store=False,
                stop_filter=lambda _: self._stop_evt.is_set(),
            )
        except Exception as exc:
            # Emit a synthetic error event so the UI can display it
            ev = NetworkEvent(
                timestamp=datetime.now().strftime("%H:%M:%S"),
                src_ip="local", dst_ip="—",
                src_port=0, dst_port=0,
                protocol="SYSTEM",
                info=f"Sniffer error: {exc}",
                severity="critical",
            )
            if self.on_event:
                self.on_event(ev)

    def _handle_pkt(self, pkt):
        self.stats["total"] += 1

        ts = datetime.now().strftime("%H:%M:%S")

        # ARP events
        if pkt.haslayer(ARP):
            if pkt[ARP].op == 2:   # ARP reply — possible poisoning
                ev = NetworkEvent(
                    timestamp=ts,
                    src_ip=pkt[ARP].psrc, dst_ip=pkt[ARP].pdst,
                    src_port=0, dst_port=0,
                    protocol="ARP",
                    info=f"ARP Reply  {pkt[ARP].psrc} → {pkt[ARP].pdst}  [{pkt[ARP].hwsrc}]",
                    severity="medium",
                )
                if self.on_event:
                    self.on_event(ev)

        # DNS queries (passive recon)
        if pkt.haslayer(DNS) and pkt.haslayer(DNSQR):
            qname = pkt[DNSQR].qname.decode("utf-8", errors="replace").rstrip(".")
            src   = pkt[IP].src if pkt.haslayer(IP) else "?"
            ev = NetworkEvent(
                timestamp=ts,
                src_ip=src, dst_ip="DNS",
                src_port=0, dst_port=53,
                protocol="DNS",
                info=f"Query  {qname}",
                severity="info",
            )
            if self.on_event:
                self.on_event(ev)

        # TCP payloads
        if pkt.haslayer(IP) and pkt.haslayer(TCP) and pkt.haslayer(Raw):
            src_ip, dst_ip = pkt[IP].src, pkt[IP].dst
            sp, dp = pkt[TCP].sport, pkt[TCP].dport
            payload = bytes(pkt[Raw].load)
            self.stats["bytes"] += len(payload)

            proto = INSECURE_PORTS.get(dp) or INSECURE_PORTS.get(sp)
            if proto:
                self.stats[proto] = self.stats.get(proto, 0) + 1

            creds, events = self.parser.parse(src_ip, dst_ip, sp, dp, payload)

            for cred in creds:
                self.stats["credentials"] += 1
                if self.on_credential:
                    self.on_credential(cred)

            for ev in events:
                if self.on_event:
                    self.on_event(ev)

            # Generic insecure protocol event
            if proto and not creds:
                ev = NetworkEvent(
                    timestamp=ts,
                    src_ip=src_ip, dst_ip=dst_ip,
                    src_port=sp, dst_port=dp,
                    protocol=proto,
                    info=f"{proto} traffic  {len(payload)}B",
                    severity="medium" if proto in ("HTTP","FTP","Telnet") else "info",
                    size=len(payload),
                )
                if self.on_event:
                    self.on_event(ev)

        if self.on_stat:
            self.on_stat(self.stats.copy())

    # ── demo / fallback mode when Scapy not available ──────────────────────

    def _demo_mode(self):
        """Generate realistic fake traffic so the UI is demonstrable without root."""
        import random, time, itertools
        hosts = [
            "192.168.1.101", "192.168.1.102", "192.168.1.103",
            "10.0.0.45",     "10.0.0.67",     "172.16.0.12",
        ]
        gateway = "192.168.1.1"
        users   = ["alice", "bob", "charlie", "dave", "eve", "admin", "root", "john.doe"]
        pwds    = ["password", "letmein", "1234567", "qwerty", "hunter2", "pass123", "monkey"]
        protos  = [
            ("HTTP", 80, "Form POST"),
            ("FTP",  21, "FTP AUTH"),
            ("Telnet", 23, "Telnet Auth"),
            ("POP3", 110, "POP3 Auth"),
            ("SMTP", 25,  "AUTH PLAIN"),
        ]

        tick = 0
        while not self._stop_evt.is_set():
            tick += 1
            time.sleep(random.uniform(0.4, 1.8))

            src = random.choice(hosts)
            proto_name, port, method = random.choice(protos)
            user = random.choice(users)
            pw   = random.choice(pwds)

            ts = datetime.now().strftime("%H:%M:%S")

            cred = Credential(
                timestamp=ts,
                src_ip=src,
                dst_ip=gateway,
                src_port=random.randint(40000, 65000),
                dst_port=port,
                protocol=proto_name,
                username=user,
                password=pw,
                method=method,
                hostname=f"server{random.randint(1,5)}.lab.internal",
            )
            self.stats["credentials"] += 1
            self.stats["total"] += random.randint(5, 30)
            self.stats[proto_name] = self.stats.get(proto_name, 0) + 1
            if self.on_credential:
                self.on_credential(cred)

            # Also emit some benign events
            ev = NetworkEvent(
                timestamp=ts,
                src_ip=src, dst_ip=gateway,
                src_port=random.randint(40000, 65000),
                dst_port=port,
                protocol=proto_name,
                info=f"Insecure {proto_name} connection from {src}",
                severity="high" if proto_name in ("HTTP","FTP","Telnet") else "medium",
                size=random.randint(128, 4096),
            )
            if self.on_event:
                self.on_event(ev)
            if self.on_stat:
                self.on_stat(self.stats.copy())
