"""
DatabaseLogger  —  persists credentials, events, and sessions to SQLite.
"""

import sqlite3
import threading
import os
from datetime import datetime
from typing import Optional

from core.protocols import Credential, NetworkEvent
from core.mitm import Session


DB_PATH = os.path.expanduser("~/.sheepwall/captures.db")


class DatabaseLogger:
    def __init__(self, db_path: str = DB_PATH):
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.db_path = db_path
        self._lock = threading.Lock()
        self._init_db()

    def _conn(self):
        return sqlite3.connect(self.db_path, check_same_thread=False)

    def _init_db(self):
        with self._lock:
            con = self._conn()
            cur = con.cursor()
            cur.executescript("""
                CREATE TABLE IF NOT EXISTS credentials (
                    id        INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts        TEXT,
                    src_ip    TEXT,
                    dst_ip    TEXT,
                    src_port  INTEGER,
                    dst_port  INTEGER,
                    protocol  TEXT,
                    username  TEXT,
                    password  TEXT,
                    method    TEXT,
                    hostname  TEXT
                );
                CREATE TABLE IF NOT EXISTS events (
                    id        INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts        TEXT,
                    src_ip    TEXT,
                    dst_ip    TEXT,
                    protocol  TEXT,
                    info      TEXT,
                    severity  TEXT,
                    size      INTEGER
                );
                CREATE TABLE IF NOT EXISTS sessions (
                    id        TEXT PRIMARY KEY,
                    ts        TEXT,
                    src_ip    TEXT,
                    dst_ip    TEXT,
                    src_port  INTEGER,
                    dst_port  INTEGER,
                    protocol  TEXT,
                    bytes     INTEGER,
                    status    TEXT
                );
            """)
            con.commit()
            con.close()

    def log_credential(self, cred: Credential):
        with self._lock:
            con = self._conn()
            con.execute(
                "INSERT INTO credentials VALUES (NULL,?,?,?,?,?,?,?,?,?,?)",
                (cred.timestamp, cred.src_ip, cred.dst_ip,
                 cred.src_port, cred.dst_port, cred.protocol,
                 cred.username, cred.password, cred.method, cred.hostname),
            )
            con.commit()
            con.close()

    def log_event(self, ev: NetworkEvent):
        with self._lock:
            con = self._conn()
            con.execute(
                "INSERT INTO events VALUES (NULL,?,?,?,?,?,?,?)",
                (ev.timestamp, ev.src_ip, ev.dst_ip,
                 ev.protocol, ev.info, ev.severity, ev.size),
            )
            con.commit()
            con.close()

    def log_session(self, sess: Session):
        with self._lock:
            con = self._conn()
            con.execute(
                """INSERT OR REPLACE INTO sessions VALUES (?,?,?,?,?,?,?,?,?)""",
                (sess.id, sess.start_time, sess.src_ip, sess.dst_ip,
                 sess.src_port, sess.dst_port, sess.protocol,
                 sess.bytes_intercepted, sess.status),
            )
            con.commit()
            con.close()

    def count_credentials(self) -> int:
        with self._lock:
            con = self._conn()
            r = con.execute("SELECT COUNT(*) FROM credentials").fetchone()
            con.close()
            return r[0] if r else 0

    def recent_credentials(self, limit: int = 100) -> list[dict]:
        with self._lock:
            con = self._conn()
            rows = con.execute(
                "SELECT ts,src_ip,dst_ip,protocol,username,password,method,hostname "
                "FROM credentials ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
            con.close()
        return [
            dict(zip(["ts","src","dst","proto","user","pass","method","host"], r))
            for r in rows
        ]

    def recent_events(self, limit: int = 200) -> list[dict]:
        with self._lock:
            con = self._conn()
            rows = con.execute(
                "SELECT ts,src_ip,dst_ip,protocol,info,severity,size "
                "FROM events ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
            con.close()
        return [
            dict(zip(["ts","src","dst","proto","info","severity","size"], r))
            for r in rows
        ]

    def export_csv(self, path: str):
        import csv
        rows = self.recent_credentials(9999)
        with open(path, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=rows[0].keys() if rows else [])
            w.writeheader()
            w.writerows(rows)
        return path
