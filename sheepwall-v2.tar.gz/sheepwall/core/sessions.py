"""
SessionManager  —  tracks intercepted TCP sessions, extracts
HTTP cookies, auth tokens, request/response pairs for replay.
"""

import re
import threading
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


# ── HTTP session data extracted from intercepted traffic ─────────────────────

@dataclass
class HttpRequest:
    method: str
    path: str
    host: str
    headers: dict
    body: str
    raw: bytes

@dataclass
class Cookie:
    name: str
    value: str
    domain: str
    flags: str = ""   # Secure, HttpOnly, SameSite=...

@dataclass
class CapturedSession:
    id: str
    timestamp: str
    src_ip: str
    dst_ip: str
    src_port: int
    dst_port: int
    protocol: str
    status: str = "LIVE"       # LIVE | CLOSED | REPLAYED

    # HTTP specifics
    host: str = ""
    method: str = ""
    path: str = ""
    user_agent: str = ""
    cookies: list = field(default_factory=list)
    auth_header: str = ""
    post_body: str = ""
    response_code: int = 0
    request_raw: str = ""
    response_raw: str = ""
    bytes_in: int = 0
    bytes_out: int = 0


# ── Regex ─────────────────────────────────────────────────────────────────────

_COOKIE_RE    = re.compile(rb'Cookie:\s*([^\r\n]+)', re.I)
_SETCOOKIE_RE = re.compile(rb'Set-Cookie:\s*([^\r\n]+)', re.I)
_UA_RE        = re.compile(rb'User-Agent:\s*([^\r\n]+)', re.I)
_HOST_RE      = re.compile(rb'Host:\s*([^\r\n]+)', re.I)
_METHOD_RE    = re.compile(rb'^(GET|POST|PUT|DELETE|PATCH|HEAD)\s+(\S+)', re.I | re.M)
_AUTH_RE      = re.compile(rb'Authorization:\s*([^\r\n]+)', re.I)
_RESP_CODE_RE = re.compile(rb'^HTTP/\d\.\d\s+(\d{3})', re.I | re.M)
_CONTENT_RE   = re.compile(rb'Content-Type:\s*([^\r\n]+)', re.I)


class SessionManager:
    """Builds CapturedSession objects from raw TCP payload streams."""

    def __init__(self):
        self._lock = threading.Lock()
        self._sessions: dict[tuple, CapturedSession] = {}
        self._complete:  list[CapturedSession] = []
        self._counter = 0

        self.on_session_update = None   # callback(CapturedSession)

    # ── public ────────────────────────────────────────────────────────────────

    def feed(self, src_ip: str, dst_ip: str, src_port: int, dst_port: int,
             payload: bytes, direction: str = "→"):
        """Feed a raw TCP payload fragment into the session tracker."""
        key = (src_ip, dst_ip, src_port, dst_port)
        rev = (dst_ip, src_ip, dst_port, src_port)

        with self._lock:
            # Normalise key so client→server and server→client share one session
            canonical = key if key in self._sessions or rev not in self._sessions else rev

            if canonical not in self._sessions:
                self._counter += 1
                self._sessions[canonical] = CapturedSession(
                    id=f"S{self._counter:04d}",
                    timestamp=datetime.now().strftime("%H:%M:%S"),
                    src_ip=src_ip, dst_ip=dst_ip,
                    src_port=src_port, dst_port=dst_port,
                    protocol=self._proto(dst_port),
                )

            sess = self._sessions[canonical]

        self._parse_http(sess, payload, direction)

        if self.on_session_update:
            self.on_session_update(sess)

    def get_all(self) -> list[CapturedSession]:
        with self._lock:
            return list(self._sessions.values())

    def get_by_id(self, sid: str) -> Optional[CapturedSession]:
        with self._lock:
            for s in self._sessions.values():
                if s.id == sid:
                    return s
        return None

    def close_session(self, sid: str):
        with self._lock:
            for s in self._sessions.values():
                if s.id == sid:
                    s.status = "CLOSED"
                    break

    # ── parsing ───────────────────────────────────────────────────────────────

    def _parse_http(self, sess: CapturedSession, data: bytes, direction: str):
        if not data:
            return

        # Request (client → server)
        mm = _METHOD_RE.search(data)
        if mm:
            sess.method = mm.group(1).decode("utf-8", errors="replace")
            sess.path   = mm.group(2).decode("utf-8", errors="replace")

        hm = _HOST_RE.search(data)
        if hm:
            sess.host = hm.group(1).decode("utf-8", errors="replace").strip()

        um = _UA_RE.search(data)
        if um:
            sess.user_agent = um.group(1).decode("utf-8", errors="replace").strip()

        am = _AUTH_RE.search(data)
        if am:
            sess.auth_header = am.group(1).decode("utf-8", errors="replace").strip()

        # Cookie parsing
        cm = _COOKIE_RE.search(data)
        if cm:
            raw_cookies = cm.group(1).decode("utf-8", errors="replace")
            for pair in raw_cookies.split(";"):
                pair = pair.strip()
                if "=" in pair:
                    n, v = pair.split("=", 1)
                    sess.cookies.append(Cookie(
                        name=n.strip(), value=v.strip(),
                        domain=sess.host,
                    ))

        # Set-Cookie (server → client)
        scm = _SETCOOKIE_RE.search(data)
        if scm:
            raw = scm.group(1).decode("utf-8", errors="replace")
            parts = raw.split(";")
            if "=" in parts[0]:
                n, v = parts[0].split("=", 1)
                flags = "; ".join(p.strip() for p in parts[1:])
                sess.cookies.append(Cookie(
                    name=n.strip(), value=v.strip(),
                    domain=sess.host, flags=flags,
                ))

        # POST body (after blank line)
        if b"\r\n\r\n" in data:
            _, body = data.split(b"\r\n\r\n", 1)
            if body:
                sess.post_body = body.decode("utf-8", errors="replace")[:2048]
                sess.bytes_in += len(body)

        # Response code
        rc = _RESP_CODE_RE.search(data)
        if rc:
            sess.response_code = int(rc.group(1))
            sess.bytes_out += len(data)

        # Store raw (truncated)
        if direction == "→":
            sess.request_raw  = data.decode("utf-8", errors="replace")[:4096]
        else:
            sess.response_raw = data.decode("utf-8", errors="replace")[:4096]

    @staticmethod
    def _proto(port: int) -> str:
        return {80:"HTTP",8080:"HTTP",21:"FTP",23:"Telnet",25:"SMTP",110:"POP3",143:"IMAP"}.get(port,"TCP")

    # ── demo data ─────────────────────────────────────────────────────────────

    def inject_demo_session(self):
        import random
        self._counter += 1
        hosts  = ["192.168.1.101","10.0.0.45","172.16.0.12","192.168.10.88"]
        paths  = ["/login","/admin","/webmail","/api/auth","/dashboard"]
        agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "curl/7.88.1",
            "python-requests/2.31.0",
        ]
        src = random.choice(hosts)
        sess = CapturedSession(
            id=f"S{self._counter:04d}",
            timestamp=datetime.now().strftime("%H:%M:%S"),
            src_ip=src, dst_ip="192.168.1.1",
            src_port=random.randint(40000,65000),
            dst_port=80,
            protocol="HTTP",
            status="LIVE",
            host=f"webserver{random.randint(1,3)}.lab.internal",
            method=random.choice(["GET","POST"]),
            path=random.choice(paths),
            user_agent=random.choice(agents),
            response_code=random.choice([200,302,401,403]),
            bytes_in=random.randint(256,8192),
            bytes_out=random.randint(512,16384),
        )
        # Inject fake cookies
        cookie_names = ["PHPSESSID","session","auth_token","JSESSIONID","csrftoken","remember_me"]
        for _ in range(random.randint(1,3)):
            import hashlib, os
            token = hashlib.md5(os.urandom(8)).hexdigest()
            sess.cookies.append(Cookie(
                name=random.choice(cookie_names),
                value=token,
                domain=sess.host,
                flags="HttpOnly; Path=/" if random.random() > 0.5 else "",
            ))
        sess.request_raw = (
            f"{sess.method} {sess.path} HTTP/1.1\r\n"
            f"Host: {sess.host}\r\n"
            f"User-Agent: {sess.user_agent}\r\n"
            f"Cookie: {'; '.join(f'{c.name}={c.value}' for c in sess.cookies)}\r\n"
            f"\r\n"
        )
        if sess.method == "POST":
            users = ["alice","bob","admin","student1"]
            sess.post_body = f"username={random.choice(users)}&password=hunter2&_token=abc123"
            sess.request_raw += sess.post_body

        with self._lock:
            self._sessions[(sess.src_ip, sess.dst_ip, sess.src_port, sess.dst_port)] = sess
        if self.on_session_update:
            self.on_session_update(sess)
        return sess
